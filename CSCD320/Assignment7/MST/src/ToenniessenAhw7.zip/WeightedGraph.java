import java.util.*;

class WeightedGraph {
    private int size;
    private LinkedList<Edge>[] adjList;

    WeightedGraph(int i) {
        this.size = i;
        adjList = new LinkedList[size];
        for (int n = 0; n < size; n++) {
            adjList[n] = new LinkedList<>();
        }
    }

    void addEdge(int n1, int n2, int w) {
        Edge e = new Edge(n1, n2, w);
        adjList[e.vertex1].add(e);
        adjList[e.vertex2].add(e);
    }

    void Kruskals() {
        Set<Edge> mst = new HashSet<>();
        SortedSet<Edge> edges = new TreeSet<>();
        for (LinkedList l : adjList) {
            for (Object e : l) {
                edges.add((Edge) e);
            }
        }
        UnionFind uf = new UnionFind();
        int n = 0;
        for (Edge e : edges) {
            if(n == edges.size() - 1)
                break;
            if (uf.merge(uf.find(e.vertex1), uf.find(e.vertex2))) {
                mst.add(e);
            }
            n++;
        }
        print(mst);
    }

    private void print(Set<Edge> a) {
        for (Edge i : a) {
            System.out.print(i.vertex1 + "->" + i.vertex2 + "\n");

        }
    }

    private class Edge implements Comparable<Edge> {
        private int vertex1, vertex2;
        private final double weight;

        Edge(int v1, int v2, double w) {
            this.vertex1 = v1;
            this.vertex2 = v2;
            this.weight = w;
        }

        public int compareTo(Edge that) {
            return (int) (this.weight - that.weight);
        }
    }

    private class UnionFind {
        private ArrayList<HashSet<Integer>> components = new ArrayList<>();

        UnionFind(){
            for(int i = 0; i < size; i++){
                HashSet<Integer> temp = new HashSet<>();
                temp.add(i);
                components.add(temp);
            }
        }

        int find(int vertex) {
            for(HashSet<Integer> h : components){
                if(h.contains(vertex))
                    return components.indexOf(h);
            }
            return -1;
        }

        boolean merge(int index1, int index2) {
            if(index1 != index2 && (index1 != -1 && index2 != -1)){
                HashSet<Integer> temp = components.get(index1);
                HashSet<Integer> temp2 = components.get(index2);
                for(Integer i : temp2){
                    if(!temp.contains(i))
                        temp.add(i);
                }
                return components.remove(temp2);
            }
            return false;
        }

    }
}