package DungeonCharacters.Heros.SpecialMoves;

import DungeonCharacters.DungeonCharacter;

public class CrushingBlow implements SpecialMove {
    public void specialMove(DungeonCharacter hero, DungeonCharacter Monster){
        if (Math.random() <= .4)
        {
            int blowPoints = (int)(Math.random() * 76) + 100;
            System.out.println(hero.getName() + " lands a CRUSHING BLOW for " + blowPoints
                    + " damage!");
            Monster.subtractHitPoints(blowPoints);
        }//end blow succeeded
        else
        {
            System.out.println(hero.getName() + " failed to land a crushing blow");
            System.out.println();
        }//blow failed
    }
}
