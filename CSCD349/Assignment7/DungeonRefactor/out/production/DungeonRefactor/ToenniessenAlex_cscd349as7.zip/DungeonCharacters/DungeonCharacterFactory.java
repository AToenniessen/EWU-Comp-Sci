package DungeonCharacters;

import DungeonCharacters.Heros.*;
import DungeonCharacters.Heros.SpecialMoves.CrushingBlow;
import DungeonCharacters.Heros.SpecialMoves.IncreaseHP;
import DungeonCharacters.Heros.SpecialMoves.SupriseAttack;
import DungeonCharacters.Monsters.*;

public class DungeonCharacterFactory {
    public static DungeonCharacter createHero(int i) {
        switch (i) {
            case (1):
                return new Hero("Warrior",  125, 4, .8, 35, 60, .2, " swings a mighty sword at ",  new CrushingBlow(), "Crushing Blow");
            case (2):
                return new Hero("Sorceress",75, 5, .7, 25, 50, .3, " casts a spell of fireball at " ,new IncreaseHP(), "Increase Hit Points");
            case (3):
                return new Hero("Thief", 75, 6, .8, 20, 40, .5, " slices with his dagger ", new SupriseAttack(), "Surprise Attack");
            default:
                System.out.println("invalid choice, returning Thief");
                return new Hero("Thief", 75, 6, .8, 20, 40, .5, " slices with his dagger ", new SupriseAttack(), "Surprise Attack");
        }
    }
    public static DungeonCharacter createMonster(int i) {
        switch (i) {
            case (1):
                return new Monster("Oscar the Ogre", 200, 2, .6, .1, 30, 50, 30, 50, " slowly swings a club toward's ");
            case (2):
                return new Monster("Gnarltooth the Gremlin", 70, 5, .8, .4, 15, 30, 20, 40, " jabs his kris at ");
            case (3):
                return new Monster("Sargath the Skeleton",  100, 3, .8, .3, 30, 50, 30, 50, " slices his rusty blade at ");
            default:
                System.out.println("invalid choice, returning Skeleton");
                return new Monster("Sargath the Skeleton",  100, 3, .8, .3, 30, 50, 30, 50, " slices his rusty blade at ");
        }
    }
}
