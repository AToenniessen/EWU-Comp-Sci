package DungeonCharacters.Heros.SpecialMoves;

import DungeonCharacters.DungeonCharacter;

public class IncreaseHP implements SpecialMove {
    public void specialMove(DungeonCharacter hero, DungeonCharacter Monster){
        int hPoints;

        hPoints = (int)(Math.random() * (50 - 25 + 1)) + 25;
        hero.addHitPoints(hPoints);
        System.out.println(hero.getName() + " added [" + hPoints + "] points.\n"
                + "Total hit points remaining are: "
                + hero.getHitPoints());
        System.out.println();
    }
}
