package DungeonCharacters.Heros.SpecialMoves;

import DungeonCharacters.DungeonCharacter;

public interface SpecialMove {
    void specialMove(DungeonCharacter Hero, DungeonCharacter Monster);
}
