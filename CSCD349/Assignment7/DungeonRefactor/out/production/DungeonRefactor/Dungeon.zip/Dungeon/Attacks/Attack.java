package Dungeon.Attacks;

import Dungeon.DungeonCharacter;

public interface Attack {
    void attack(DungeonCharacter attacker, DungeonCharacter defender);
    String getAttack();
}
