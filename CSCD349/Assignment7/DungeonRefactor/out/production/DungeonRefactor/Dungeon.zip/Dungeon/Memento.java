package Dungeon;

import java.io.Serializable;

public class Memento implements Serializable{
    private final DungeonCharacter state;

    public Memento(DungeonCharacter c){
        state = c;
    }
    public DungeonCharacter getSavedState(){
        return state;
    }
}
